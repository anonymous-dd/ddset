; not worky
;#{'[] []}
#{'1 1}
