(let [{::keys [:foo]} {::foo 1}] foo)
