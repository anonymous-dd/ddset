(try "something" (catch Object o "oops"))
