var listener;
self.addEventListener( 'click' , listener = function(bar){
  console.log(listener);
});
