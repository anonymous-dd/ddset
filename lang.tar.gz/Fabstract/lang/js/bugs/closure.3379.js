"a".length >>= 1;
