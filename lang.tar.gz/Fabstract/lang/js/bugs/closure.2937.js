var A = class  extends (class {}){};
