var {baz:{} = baz => {}} = baz => {};
