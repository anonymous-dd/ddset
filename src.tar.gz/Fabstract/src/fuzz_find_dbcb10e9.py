import Fuzz as F
import find_dbcb10e9 as Main

if __name__ == '__main__':
    F.main('./lang/find/grammar/grammar.json', './lang/find/bugs/find.dbcb10e9', Main.my_predicate)
