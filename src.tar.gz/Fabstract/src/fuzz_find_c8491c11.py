import Fuzz as F
import find_c8491c11 as Main

if __name__ == '__main__':
    F.main('./lang/find/grammar/grammar.json', './lang/find/bugs/find.c8491c11', Main.my_predicate)
